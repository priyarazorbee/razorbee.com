<?php
error_reporting(1);
$server="localhost";
$user="root";
$pass="razorbee123";
$db="elec"; 
$con=mysqli_connect($server,$user,$pass,$db);
?>
